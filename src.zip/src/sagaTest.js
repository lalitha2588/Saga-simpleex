import { call, put, takeEvery } from 'redux-saga/effects';
import { updateAnimal } from './slice'

function* callApi() {
    const loadAnimal = yield call(() => fetch("https://api.thecatapi.com/v1/breeds"))
    const formatJson = yield loadAnimal.json()
    const showLess = formatJson.slice(1, 10)
    yield put(updateAnimal(showLess))

}

function* watchanimalSaga() {
    yield takeEvery("animal/getAnimal", callApi)
}

export default watchanimalSaga