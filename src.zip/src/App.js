import './App.css';
import { useSelector, useDispatch } from 'react-redux';
import { getAnimal } from './slice';
import { useEffect } from 'react';

function App() {
  const animal = useSelector(state => state.animal.animals)
  const dispatch = useDispatch()
  useEffect(() => {
    dispatch(getAnimal())
  }, [dispatch])
  console.log(animal)
  return (
    <div className="App">
      <p>Cats</p>
      <div className='Gallery'>
        {animal.map((item,e) => (
          <ul key={e.id}>
            <li>{item.name}</li>
          </ul>
        ))}
      </div>

    </div>
  );
}

export default App;
