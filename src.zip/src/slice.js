import { createSlice } from "@reduxjs/toolkit";

export const animalSlice = createSlice({
    name: "animal",
    initialState: {
        animals: [],
        isLoading: false
    },
    reducers: {
        getAnimal: (state) => {
            state.isLoading = true;
        },
        updateAnimal: (state, action) => {
            state.animals = action.payload;
            state.isLoading = false;
        }
    }
})
export const {getAnimal,updateAnimal} =animalSlice.actions;
export default animalSlice.reducer